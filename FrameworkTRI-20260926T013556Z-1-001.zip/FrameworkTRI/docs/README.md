# FrameworkTRI

**Versão:** 0.1 (Em desenvolvimento)

# Visão Geral

O FrameworkTRI é uma plataforma aberta para análise psicométrica de avaliações educacionais.

Seu objetivo é disponibilizar uma infraestrutura completa para preparação de dados, Teoria Clássica dos Testes (TCT), Teoria da Resposta ao Item (TRI), calibração de itens, equalização de escalas (linking), banco de itens, montagem automática de provas e geração de relatórios.

## Objetivos

- Padronizar o tratamento de diferentes avaliações.
- Disponibilizar uma arquitetura única para análises psicométricas.
- Implementar métodos clássicos e modernos de avaliação.
- Permitir reutilização de algoritmos.
- Produzir resultados reproduzíveis.
- Servir como base para aplicações educacionais em produção.
- Servir como base para pesquisas científicas.

## Fluxo de Desenvolvimento

1. Especificação
2. Implementação
3. Testes
4. Validação
5. Refatoração
6. Release

## Estado Atual

Status: **Em desenvolvimento**

Fase atual: **Especificação Funcional**
