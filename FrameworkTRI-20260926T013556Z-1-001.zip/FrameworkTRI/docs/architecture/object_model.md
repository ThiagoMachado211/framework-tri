# Object Model

**Documento:** Architecture 01  
**Versão:** 0.1 (Draft)

# Objetivo

Este documento define o modelo conceitual do FrameworkTRI. Ele descreve as entidades
principais do domínio e seus relacionamentos. O objetivo é servir como referência para
todas as implementações futuras.

---

# Entidade Principal

## Estudo

O objeto **Estudo** representa uma análise psicométrica completa.

Ele encapsula:

- configurações;
- uma ou mais aplicações;
- participantes;
- provas;
- resultados;
- estatísticas;
- validações.

Toda execução do FrameworkTRI produz exatamente um objeto `estudo`.

---

# Entidades do Domínio

## Aplicação

Representa uma realização específica de uma avaliação.

Exemplos:

- ENEM 2025
- Simulado 01
- Simulado 02

---

## Participante

Representa um indivíduo submetido à avaliação.

Cada participante possui:

- identificador único;
- respostas;
- resultados derivados.

---

## Área

Uma aplicação pode conter uma ou mais áreas.

As áreas padrão do FrameworkTRI são:

- CH
- CN
- LC
- MT

A arquitetura deverá permitir áreas adicionais.

---

## Prova

Cada área possui uma prova.

Uma prova contém:

- itens;
- gabarito;
- matriz de respostas;
- matriz de acertos.

---

## Item

Cada item representa a menor unidade de avaliação.

Atributos mínimos:

- identificador;
- posição;
- alternativa correta.

Outros atributos (habilidade, competência e parâmetros TRI) serão adicionados nas próximas releases.

---

## Resposta

Representa a alternativa marcada por um participante para um item.

Valores possíveis:

- alternativa válida;
- omissão;
- resposta inválida.

---

## Gabarito

Conjunto ordenado das respostas corretas de uma prova.

Cada prova possui exatamente um gabarito.

---

# Relacionamentos

```text
Estudo
 ├── Aplicações
 ├── Participantes
 ├── Áreas
 │     └── Provas
 │            ├── Itens
 │            ├── Gabarito
 │            ├── Matriz de Respostas
 │            └── Matriz de Acertos
 ├── Estatísticas
 └── Resultados
```

---

# Requisitos

REQ-0001 — Todo processamento ocorre sobre um único objeto `estudo`.

REQ-0002 — Uma aplicação pode conter uma ou mais áreas.

REQ-0003 — Cada área possui exatamente uma prova.

REQ-0004 — Cada prova possui exatamente um gabarito.

REQ-0005 — Cada prova produz uma matriz de respostas e uma matriz de acertos.

REQ-0006 — A estrutura deverá ser independente da origem dos dados (ENEM, SAEB ou avaliações internas).

---

# Observações

Este documento é conceitual e não define implementação em Python. A estrutura computacional será especificada posteriormente no documento de arquitetura da API.
