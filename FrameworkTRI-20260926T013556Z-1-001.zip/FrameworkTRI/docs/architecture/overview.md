# Architecture Overview

**Documento:** Architecture 03

## Objetivo

Descrever a arquitetura em alto nível do FrameworkTRI.

## Camadas

1. Entrada de Dados
2. Padronização
3. Processamento
4. Modelos Psicométricos
5. Persistência
6. Relatórios

## Princípios

- Modularidade
- Reutilização
- Independência da avaliação
- Reprodutibilidade
- Testabilidade

## Componentes

- IO
- Preprocessamento
- Validação
- Estatísticas
- TCT
- TRI
- Calibração
- Linking
- Relatórios

Cada componente deverá comunicar-se apenas por interfaces bem definidas.
