# Pipeline

**Documento:** Architecture 02
**Versão:** 0.1 (Draft)

# Objetivo

Este documento define o fluxo oficial de processamento do FrameworkTRI.

Todo processamento deverá seguir esta sequência. Nenhum módulo poderá assumir que
uma etapa posterior já foi executada.

---

# Visão Geral

```text
Entrada de Dados
        │
        ▼
Padronização
        │
        ▼
Construção das Matrizes
        │
        ▼
Correção das Respostas
        │
        ▼
Validação
        │
        ▼
Estatísticas
        │
        ▼
Teoria Clássica dos Testes
        │
        ▼
Modelos TRI
        │
        ▼
Estimadores de Proficiência
        │
        ▼
Calibração
        │
        ▼
Linking
        │
        ▼
Banco de Itens
        │
        ▼
Montagem de Provas
        │
        ▼
Relatórios
        │
        ▼
Visualizações
```

---

# Etapas

## 1. Entrada de Dados

Responsável pela importação dos microdados.

Entradas suportadas inicialmente:

- ENEM
- Avaliações internas

Saída:

- dados padronizados

---

## 2. Padronização

Responsável por transformar diferentes formatos em um único modelo interno.

Exemplos:

- padronização do identificador do participante;
- padronização das áreas;
- padronização das respostas.

---

## 3. Construção das Matrizes

Produz:

- matriz de respostas;
- gabaritos;
- matriz de acertos.

Estas estruturas serão utilizadas por todas as etapas seguintes.

---

## 4. Correção

Compara respostas e gabaritos.

Resultado:

- acerto;
- erro;
- omissão.

---

## 5. Validação

Executa verificações automáticas.

Exemplos:

- tamanho das respostas;
- duplicidades;
- alternativas inválidas;
- consistência dos gabaritos.

Caso ocorram erros críticos, o pipeline deverá interromper a execução.

---

## 6. Estatísticas

Calcula indicadores básicos das provas e dos itens.

---

## 7. TCT

Executa os indicadores clássicos.

Exemplos:

- dificuldade;
- correlação item-total;
- KR-20;
- Alfa de Cronbach.

---

## 8. TRI

Executa os modelos psicométricos.

---

## 9. Estimação

Calcula as proficiências dos participantes.

---

## 10. Calibração

Estima os parâmetros dos itens.

---

## 11. Linking

Equaliza aplicações diferentes.

---

## 12. Banco de Itens

Atualiza o banco de itens calibrados.

---

## 13. Relatórios

Produz tabelas, indicadores e relatórios.

---

## 14. Visualizações

Produz gráficos psicométricos e painéis.

---

# Requisitos

REQ-0101 — Todas as etapas deverão ser independentes.

REQ-0102 — Cada etapa possuirá entradas e saídas claramente definidas.

REQ-0103 — O objeto `estudo` será atualizado progressivamente ao longo do pipeline.

REQ-0104 — Nenhuma etapa deverá modificar resultados de etapas anteriores.

REQ-0105 — O pipeline deverá permitir execução parcial para fins de teste.

---

# Observações

As Releases do FrameworkTRI implementarão progressivamente este pipeline.
Cada nova Release acrescentará etapas sem alterar o fluxo geral.
