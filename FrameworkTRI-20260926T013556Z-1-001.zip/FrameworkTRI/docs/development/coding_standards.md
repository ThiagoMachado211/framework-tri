# Coding Standards

**Documento:** Development 01

# Convenções Gerais

- Python 3.11+
- PEP 8
- Tipagem sempre que possível.
- Uma função = uma responsabilidade.

# Nomenclatura

Funções:
- verbos no infinitivo
- snake_case

Variáveis:
- nomes descritivos

Constantes:
- MAIÚSCULAS

# Organização

Cada notebook deverá seguir:

1. Configuração
2. Imports
3. Funções
4. Pipeline
5. Exemplos
6. Testes

# Testes

Toda função pública deverá possuir teste mínimo de funcionamento.

# Logs

Mensagens devem informar início, fim e resumo da execução.
