# Validation Protocol

**Documento:** Development 02

## Objetivo

Definir como cada release será validada.

## Tipos de Validação

### Estrutural

- Colunas obrigatórias
- Tipos de dados
- Valores ausentes

### Funcional

- Matrizes consistentes
- Gabaritos únicos
- Correção correta

### Estatística

- Totais de participantes
- Distribuição de acertos
- Estatísticas reproduzíveis

## Regras

- Toda função pública deve possuir teste.
- Toda release deve possuir validação automática.
- Nenhuma release é considerada concluída sem validação manual em dados reais.
