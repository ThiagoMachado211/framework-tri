# Functional Specification

**Documento:** Functional 01
**Versão:** 0.1 (Draft)

# Objetivo

Este documento define os requisitos funcionais do FrameworkTRI.

## Escopo

O FrameworkTRI deverá fornecer uma plataforma unificada para:

- preparação de dados;
- TCT;
- TRI;
- calibração;
- linking;
- banco de itens;
- relatórios.

## Requisitos Funcionais

REQ-0001 Importar microdados do ENEM.

REQ-0002 Importar avaliações internas.

REQ-0003 Produzir um objeto `estudo` padronizado.

REQ-0004 Construir matrizes de respostas e acertos.

REQ-0005 Executar o pipeline oficial.

REQ-0006 Suportar múltiplas aplicações.

REQ-0007 Permitir execução modular.

## Requisitos Não Funcionais

NFR-0001 Funcionar no Google Colab.

NFR-0002 Independência da origem dos dados.

NFR-0003 Código reutilizável.

NFR-0004 API estável por release.

## API Pública Inicial

- carregar_enem()
- carregar_aplicacao()
- construir_matrizes()
- corrigir_respostas()
- validar_estudo()
- preparar_estudo()
- resumo_estudo()

## Critério de Aceite

Uma release somente será concluída após validação automática e manual dos resultados.
