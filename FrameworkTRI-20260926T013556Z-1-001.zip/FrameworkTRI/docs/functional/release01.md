# Release 01 – Camada de Dados

**Documento:** Functional 02

## Objetivo

Implementar toda a infraestrutura de preparação dos dados para análises psicométricas.

## Escopo

- Leitura do ENEM
- Leitura de avaliações internas
- Padronização
- Construção das matrizes
- Correção
- Validação
- Estatísticas básicas

## API

- carregar_enem()
- carregar_aplicacao()
- padronizar_dados()
- construir_matrizes()
- corrigir_respostas()
- validar_estudo()
- calcular_estatisticas()
- preparar_estudo()

## Critérios de Aceite

- ENEM processado sem adaptações.
- Avaliações internas processadas sem adaptações.
- Matrizes corretas.
- Pipeline executado integralmente.
- Testes aprovados.
