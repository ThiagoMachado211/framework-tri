# Glossário

## Aplicação
Realização específica de uma avaliação.

## Área
Conjunto de itens pertencentes a um domínio (CH, CN, LC, MT).

## Estudo
Objeto principal produzido pelo FrameworkTRI.

## Gabarito
Sequência oficial de respostas corretas.

## Item
Menor unidade de avaliação.

## Linking
Processo de equalização entre escalas.

## Participante
Pessoa submetida à avaliação.

## Prova
Conjunto organizado de itens.

## Resposta
Alternativa registrada para um item.

## TCT
Teoria Clássica dos Testes.

## TRI
Teoria da Resposta ao Item.

## Theta
Estimativa da proficiência latente.
