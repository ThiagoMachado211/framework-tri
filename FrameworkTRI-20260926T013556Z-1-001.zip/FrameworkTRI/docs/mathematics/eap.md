# EAP (Expected A Posteriori)

**Documento:** Mathematics 05

## Objetivo
Definir o estimador EAP para obtenção da proficiência.

## Entradas
- respostas do participante
- parâmetros dos itens
- distribuição a priori

## Saídas
- theta estimado
- erro padrão da estimativa

## Etapas

1. Calcular a verossimilhança.
2. Combinar com a distribuição a priori.
3. Obter a distribuição posterior.
4. Calcular a esperança da posterior.

## Requisitos
- Suporte aos modelos 1PL, 2PL e 3PL.
- Grade de integração configurável.
