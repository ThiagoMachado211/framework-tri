# Algoritmo EM

**Documento:** Mathematics 12

## Objetivo
Descrever o algoritmo Expectation-Maximization utilizado na calibração MML.

## Etapas

### Expectation (E)
Calcular estatísticas esperadas utilizando os parâmetros atuais.

### Maximization (M)
Atualizar os parâmetros maximizando a esperança da log-verossimilhança.

## Critério de parada
- Número máximo de iterações.
- Tolerância de convergência.

## Aplicações
- Calibração de itens.
- Estimação de parâmetros latentes.
