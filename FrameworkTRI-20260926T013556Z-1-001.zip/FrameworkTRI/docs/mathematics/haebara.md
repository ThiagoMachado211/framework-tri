# Haebara

**Documento:** Mathematics 16

## Objetivo
Especificar o método Haebara.

## Princípio
Minimizar diferenças entre curvas características dos itens.

## Entradas
- Itens comuns
- Parâmetros calibrados

## Saídas
- Constantes de transformação

## Observação
Método amplamente utilizado em processos de linking.
