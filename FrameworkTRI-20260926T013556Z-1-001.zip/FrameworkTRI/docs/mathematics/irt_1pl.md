# Modelo 1PL (Rasch)

**Documento:** Mathematics 02

## Objetivo
Especificar o modelo logístico de um parâmetro.

## Parâmetros
- b: dificuldade

## Suposições
- discriminação constante
- ausência de parâmetro de acerto casual

## Entradas
- respostas
- parâmetros dos itens

## Saídas
- probabilidade de acerto
- log-verossimilhança
- estimativas de proficiência

## Implementação
Será realizada na Release 3.
