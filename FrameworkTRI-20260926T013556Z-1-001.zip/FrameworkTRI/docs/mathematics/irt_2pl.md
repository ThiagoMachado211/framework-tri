# Modelo 2PL

**Documento:** Mathematics 03

## Objetivo
Especificar o modelo logístico de dois parâmetros.

## Parâmetros
- a: discriminação
- b: dificuldade

## Entradas
- respostas
- parâmetros dos itens

## Saídas
- probabilidade de acerto
- curvas características
- informação do item

## Implementação
Será realizada na Release 3.
