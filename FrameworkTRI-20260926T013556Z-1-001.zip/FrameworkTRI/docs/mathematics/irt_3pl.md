# Modelo 3PL

**Documento:** Mathematics 04

## Objetivo
Especificar o modelo logístico de três parâmetros.

## Parâmetros
- a: discriminação
- b: dificuldade
- c: acerto ao acaso

## Entradas
- matriz de respostas
- parâmetros dos itens

## Saídas
- probabilidade de acerto
- curvas características
- informação do item
- funções de verossimilhança

## Requisitos
- Compatível com o objeto `estudo`.
- Implementação vetorizada sempre que possível.

## Implementação
Prevista para a Release 3.
