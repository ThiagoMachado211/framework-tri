# Modelo 4PL

**Documento:** Mathematics 09

## Objetivo
Especificar o modelo logístico de quatro parâmetros.

## Parâmetros
- a: discriminação
- b: dificuldade
- c: acerto ao acaso
- d: limite superior

## Aplicações
Indicado para contextos onde a probabilidade máxima de acerto é inferior a 1.

## Implementação
Opcional na primeira versão do FrameworkTRI.
