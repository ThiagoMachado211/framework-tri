# Joint Maximum Likelihood (JML)

**Documento:** Mathematics 10

## Objetivo
Definir o método Joint Maximum Likelihood para estimação simultânea das proficiências dos participantes e dos parâmetros dos itens.

## Entradas
- Matriz de acertos
- Configuração do modelo TRI

## Saídas
- Parâmetros dos itens
- Proficiências

## Fluxo
1. Inicializar parâmetros.
2. Estimar proficiências.
3. Estimar parâmetros dos itens.
4. Repetir até convergência.

## Critérios
- Registrar número de iterações.
- Registrar critério de convergência.
