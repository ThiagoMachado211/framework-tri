# MAP (Maximum A Posteriori)

**Documento:** Mathematics 06

## Objetivo
Definir o estimador MAP.

## Entradas
- respostas
- parâmetros dos itens
- distribuição a priori

## Saídas
- theta estimado

## Método
Maximizar a distribuição posterior do participante.

## Requisitos
- Utilizar métodos numéricos de otimização.
- Permitir configuração dos critérios de convergência.
