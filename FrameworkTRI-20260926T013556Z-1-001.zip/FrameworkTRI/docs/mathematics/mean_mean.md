# Mean/Mean Linking

**Documento:** Mathematics 13

## Objetivo
Descrever o método Mean/Mean para equalização de escalas utilizando itens comuns.

## Entradas
- Parâmetros calibrados em duas aplicações
- Conjunto de itens âncora

## Saídas
- Constantes de transformação
- Escala equalizada

## Observações
Método simples baseado nas médias dos parâmetros.
