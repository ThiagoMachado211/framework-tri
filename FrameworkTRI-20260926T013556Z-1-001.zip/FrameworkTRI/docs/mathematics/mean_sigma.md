# Mean/Sigma Linking

**Documento:** Mathematics 14

## Objetivo
Descrever o método Mean/Sigma.

## Entradas
- Parâmetros calibrados
- Itens âncora

## Saídas
- Constantes A e B
- Nova escala

## Características
Considera diferenças de média e desvio-padrão entre aplicações.
