# MLE (Maximum Likelihood Estimation)

**Documento:** Mathematics 07

## Objetivo
Especificar o estimador de Máxima Verossimilhança.

## Entradas
- Vetor de respostas
- Parâmetros dos itens

## Saídas
- Theta estimado
- Erro padrão

## Processo
1. Construir a função de verossimilhança.
2. Calcular a log-verossimilhança.
3. Maximizar numericamente.

## Observações
Não utiliza distribuição a priori.
