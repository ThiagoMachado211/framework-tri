# Marginal Maximum Likelihood (MML)

**Documento:** Mathematics 11

## Objetivo
Especificar o método Marginal Maximum Likelihood.

## Entradas
- Matriz de respostas
- Modelo TRI
- Distribuição a priori

## Saídas
- Parâmetros calibrados

## Características
- Integração sobre a distribuição dos participantes.
- Utilização do algoritmo EM.

## Observação
Será o método principal de calibração do FrameworkTRI.
