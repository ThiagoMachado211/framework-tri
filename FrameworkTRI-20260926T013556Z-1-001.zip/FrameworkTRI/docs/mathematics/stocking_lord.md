# Stocking-Lord

**Documento:** Mathematics 15

## Objetivo
Especificar o método Stocking-Lord para equalização.

## Princípio
Encontrar as constantes de transformação minimizando a diferença entre curvas características do teste.

## Entradas
- Parâmetros dos itens âncora

## Saídas
- Constantes A e B
