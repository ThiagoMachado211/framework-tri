# WLE (Weighted Likelihood Estimation)

**Documento:** Mathematics 08

## Objetivo
Definir o estimador WLE para reduzir o viés observado no MLE.

## Entradas
- Respostas
- Parâmetros dos itens

## Saídas
- Theta estimado
- Erro padrão

## Requisitos
- Compatível com 1PL, 2PL e 3PL.
- Utilizar função de ponderação apropriada.
