# API - Release 01

Versão: 1.0

## Objetivo

Definir a interface pública da Camada de Dados do FrameworkTRI.

Todas as funções desta release deverão operar sobre o objeto `estudo`.

---

# Fluxo da API

```text
criar_estudo()
        ↓
carregar_enem() ou carregar_aplicacao()
        ↓
padronizar_dados()
        ↓
construir_matrizes()
        ↓
corrigir_respostas()
        ↓
validar_estudo()
        ↓
calcular_estatisticas()
        ↓
resumo_estudo()
```

---

# Funções

## criar_estudo(config)

Cria o objeto principal do Framework.

Entrada:
- configurações da execução

Saída:
- objeto `estudo`

---

## carregar_enem(estudo, caminho)

Importa microdados do ENEM.

---

## carregar_aplicacao(estudo, caminho)

Importa avaliações internas.

---

## padronizar_dados(estudo)

Padroniza nomes de colunas, identificadores, áreas e respostas.

---

## construir_matrizes(estudo)

Produz, para cada área:

- matriz de respostas
- gabarito
- matriz de acertos

---

## corrigir_respostas(estudo)

Compara respostas e gabaritos.

---

## validar_estudo(estudo)

Executa todas as validações da Release 01.

---

## calcular_estatisticas(estudo)

Calcula:

- participantes
- itens
- acertos
- percentual de acertos
- ausências
- respostas inválidas

---

## resumo_estudo(estudo)

Retorna um resumo da preparação dos dados.

---

# Convenções

Todas as funções:

- recebem o objeto `estudo`;
- retornam o objeto `estudo`;
- não modificam a API pública;
- lançam exceções apenas para erros críticos.

