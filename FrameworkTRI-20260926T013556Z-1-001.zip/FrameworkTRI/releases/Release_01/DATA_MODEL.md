# DATA_MODEL - Release 01

Versão: 1.0

## Objetivo

Definir a estrutura do objeto `estudo`, que será a principal estrutura de dados do FrameworkTRI.

---

# Estrutura Geral

```text
estudo
├── config
├── dados
├── aplicacoes
├── participantes
├── areas
├── provas
├── matrizes
├── estatisticas
└── validacao
```

---

## config

Armazena as configurações da execução.

Exemplos:

- tipo_avaliacao
- ano
- quantidade_itens
- areas
- idioma

---

## dados

Contém os DataFrames originais importados.

---

## aplicacoes

Lista das aplicações carregadas.

---

## participantes

Tabela padronizada contendo os identificadores dos participantes.

---

## areas

Áreas disponíveis na avaliação.

Padrão:

- CH
- CN
- LC
- MT

---

## provas

Metadados de cada prova.

Cada prova deverá conter:

- nome
- área
- quantidade de itens
- gabarito

---

## matrizes

Para cada área deverão existir:

- respostas
- gabarito
- acertos

Todas as matrizes deverão possuir:

- linhas = participantes
- colunas = itens

---

## estatisticas

Indicadores produzidos pela Release 01.

Exemplos:

- número de participantes
- número de itens
- percentual médio de acertos
- quantidade de ausentes
- quantidade de respostas inválidas

---

## validacao

Resultado das verificações automáticas.

Cada validação deverá informar:

- nome
- status
- mensagem

---

# Regras

- O objeto `estudo` será atualizado ao longo das releases.
- Nenhuma release poderá remover componentes existentes.
- Novos componentes deverão preservar compatibilidade retroativa.
