# PIPELINE - Release 01

Versão: 1.0

## Objetivo

Definir o fluxo oficial de processamento da Camada de Dados do FrameworkTRI.

Toda implementação da Release 01 deverá seguir exatamente esta sequência.

---

# Pipeline

```text
1. criar_estudo()

        ↓

2. carregar_enem()
   ou
   carregar_aplicacao()

        ↓

3. padronizar_dados()

        ↓

4. construir_matrizes()

        ↓

5. corrigir_respostas()

        ↓

6. validar_estudo()

        ↓

7. calcular_estatisticas()

        ↓

8. resumo_estudo()
```

---

# Descrição das Etapas

## 1. criar_estudo()

Inicializa o objeto `estudo`.

Cria todas as estruturas vazias que serão preenchidas nas etapas seguintes.

---

## 2. carregar_enem() / carregar_aplicacao()

Importa os dados da avaliação.

Responsável apenas pela leitura dos arquivos.

Nenhuma transformação deverá ocorrer nesta etapa.

---

## 3. padronizar_dados()

Converte os diferentes formatos para o modelo interno do FrameworkTRI.

Inclui:

- padronização dos identificadores;
- padronização das áreas;
- padronização das respostas;
- padronização dos gabaritos.

---

## 4. construir_matrizes()

Produz, para cada área:

- matriz de respostas;
- vetor gabarito;
- matriz de acertos.

Todas as matrizes deverão possuir a mesma ordem de participantes.

---

## 5. corrigir_respostas()

Compara respostas e gabaritos.

Resultado esperado:

- acerto;
- erro;
- omissão.

---

## 6. validar_estudo()

Executa todas as verificações da Release 01.

Exemplos:

- quantidade de itens;
- gabaritos consistentes;
- participantes duplicados;
- respostas inválidas.

Erros críticos deverão interromper o pipeline.

---

## 7. calcular_estatisticas()

Calcula indicadores básicos.

- participantes;
- itens;
- percentual médio de acertos;
- ausências;
- respostas inválidas.

---

## 8. resumo_estudo()

Produz um resumo final da preparação dos dados.

Este resumo será utilizado pelas próximas releases.

---

# Regras

- Nenhuma etapa poderá modificar resultados de etapas anteriores.
- O objeto `estudo` deverá ser atualizado progressivamente.
- Cada etapa deverá possuir testes independentes.
