# PROMPT_CODEX - Release 01

Você é o responsável por implementar integralmente a Release 01 do FrameworkTRI.

## Leia obrigatoriamente os seguintes documentos

- README.md
- API.md
- DATA_MODEL.md
- PIPELINE.md
- REQUIREMENTS.md
- IMPLEMENTATION_GUIDE.md
- TEST_PLAN.md

Todos os documentos estão na pasta `releases/Release_01/`.

---

## Objetivo

Implementar toda a camada de preparação de dados do FrameworkTRI.

---

## Escopo

Implemente exclusivamente:

- criar_estudo()
- carregar_enem()
- carregar_aplicacao()
- padronizar_dados()
- construir_matrizes()
- corrigir_respostas()
- validar_estudo()
- calcular_estatisticas()
- preparar_estudo()
- resumo_estudo()

---

## Requisitos

- Respeitar integralmente a API pública.
- Utilizar Python 3.11.
- Compatibilidade total com Google Colab.
- Utilizar apenas pandas e numpy como dependências obrigatórias.
- Implementar testes mínimos previstos em TEST_PLAN.md.
- O objeto `estudo` deverá seguir exatamente DATA_MODEL.md.

---

## Fora do escopo

Não implementar:

- TCT
- TRI
- EAP
- MAP
- MLE
- Calibração
- Linking
- Banco de Itens

---

## Entrega

Entregar um notebook executável no Google Colab contendo toda a implementação da Release 01, incluindo exemplos de uso e testes básicos.
