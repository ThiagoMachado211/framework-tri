# REQUIREMENTS - Release 01

Versão: 1.0

## Objetivo

Definir os requisitos funcionais e não funcionais da Release 01.

---

# Requisitos Funcionais

## RF-001
O Framework deverá importar microdados do ENEM.

## RF-002
O Framework deverá importar avaliações internas.

## RF-003
O Framework deverá padronizar ambas as estruturas em um único modelo interno.

## RF-004
O Framework deverá construir, para cada área, o vetor de gabarito.

## RF-005
O Framework deverá construir a matriz de respostas.

## RF-006
O Framework deverá construir a matriz de acertos.

## RF-007
O Framework deverá identificar respostas omitidas.

## RF-008
O Framework deverá identificar respostas inválidas.

## RF-009
O Framework deverá executar validações automáticas.

## RF-010
O Framework deverá calcular estatísticas básicas da preparação dos dados.

## RF-011
O Framework deverá produzir um objeto denominado `estudo`.

## RF-012
Toda a API deverá operar exclusivamente sobre o objeto `estudo`.

---

# Requisitos Não Funcionais

## RNF-001
Compatibilidade total com Google Colab.

## RNF-002
Compatibilidade com Python 3.11 ou superior.

## RNF-003
Utilizar apenas pandas e numpy como dependências obrigatórias.

## RNF-004
Todo processamento deverá ser vetorizado sempre que possível.

## RNF-005
O código deverá ser organizado em funções reutilizáveis.

## RNF-006
A implementação deverá ser independente da origem dos dados.

---

# Critérios de Aceite

A Release 01 será considerada concluída quando:

- todos os requisitos funcionais forem implementados;
- todas as validações forem aprovadas;
- o notebook executar integralmente sem intervenção manual;
- o objeto `estudo` estiver pronto para ser utilizado pelas Releases seguintes.
