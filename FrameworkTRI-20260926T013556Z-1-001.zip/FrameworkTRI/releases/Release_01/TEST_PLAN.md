# TEST_PLAN - Release 01

Versão: 1.0

## Objetivo

Definir os testes mínimos necessários para validar a implementação da Release 01.

---

# Testes Funcionais

## TF-001 — Leitura do ENEM

Entrada:
- Microdados do ENEM

Resultado esperado:
- Dados carregados sem erros.
- Quatro áreas identificadas.

---

## TF-002 — Leitura de Avaliação Interna

Entrada:
- Arquivo de avaliação interna

Resultado esperado:
- Áreas reconstruídas corretamente.
- Participantes identificados.

---

## TF-003 — Padronização

Verificar:

- nomes de colunas;
- identificadores;
- áreas;
- respostas.

---

## TF-004 — Construção das Matrizes

Para cada área:

- matriz de respostas;
- vetor gabarito;
- matriz de acertos.

Verificar dimensões e consistência.

---

## TF-005 — Correção

Casos:

- resposta correta;
- resposta incorreta;
- omissão;
- resposta inválida.

---

## TF-006 — Estatísticas

Verificar:

- número de participantes;
- número de itens;
- percentual médio de acertos;
- quantidade de omissões;
- quantidade de respostas inválidas.

---

## TF-007 — Pipeline Completo

Executar:

```python
estudo = preparar_estudo(...)
```

Resultado esperado:

- execução sem intervenção manual;
- objeto `estudo` válido.

---

# Critérios de Aprovação

A Release 01 será aprovada quando:

- todos os testes forem aprovados;
- nenhuma exceção inesperada ocorrer;
- o objeto `estudo` estiver consistente;
- o notebook executar integralmente no Google Colab.
